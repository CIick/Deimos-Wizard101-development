import asyncio
import wizwalker
from wizwalker import Keycode, HotkeyListener, ModifierKeys, utils
from wizwalker import WizWalker
from wizwalker.client_handler import ClientHandler
from wizwalker.memory import Window
from loguru import logger


# @logger.catch
# class Read_Backpack_Contents():
#     def __init__(self, client):
#         client = client

async def is_control_grayed(button):
    return await button.read_value_from_offset(688, "bool")


async def get_window_from_path(root_window: Window, name_path):
    async def _recurse_follow_path(window, path):
        if len(path) == 0:
            return window

        for child in await window.children():
            if await child.name() == path[0]:
                found_window = await _recurse_follow_path(child, path[1:])
                if not found_window is False:
                    return found_window

        return False

    return await _recurse_follow_path(root_window, name_path)


async def wait_for_window_to_exist(parent_window, name, delay=0):
    if type(name) is str:
        while len(w := await parent_window.get_windows_with_name(name)) == 0:
            (delay > 0) and await asyncio.sleep(delay)

        return w[0]

    elif type(name) is list:
        while not (w := await get_window_from_path(parent_window, name)):
            (delay > 0) and await asyncio.sleep(delay)

        return w


async def scan(client):
    template = await client.client_object.object_template()
    school = await template.primary_school_name()
    backpack_tabs = ["Tab_Hat", "Tab_Robe", "Tab_Shoes", "Tab_Weapon", "Tab_Athame", "Tab_Amulet", "Tab_Ring"]
    for tab in backpack_tabs:
        await client.mouse_handler.click_window_with_name(tab)
        for i in range(1, 9):
            try:
                selected_item = await get_window_from_path(client.root_window, ["WorldView", "DeckConfiguration", f"InventorySpellbookPage", f"Item_{i}"])
                valid = await is_control_grayed(selected_item)
                if valid:
                    continue

                fist_path = await get_window_from_path(selected_item, ["fist"])

                if await fist_path.is_visible():
                    continue
                await client.mouse_handler.set_mouse_position_to_window(selected_item)

                popup = await wait_for_window_to_exist(client.root_window, ["WorldView", "compareNewItem", "ControlWidget", "mainLayout"])
                window = await get_window_from_path(client.root_window, ["WorldView", "compareNewItem", "ControlWidget", "mainLayout"])
                child = await window.children()
                for stat in range(len(child)):
                    line_of_stat = await child[stat].maybe_text()
                    line_of_stat = line_of_stat.lower()
                    if "damage" in line_of_stat:
                        if "storm" in line_of_stat:
                            cluttered_damage_stat = await child[stat].maybe_text()
                            plus_position = cluttered_damage_stat.find('+')
                            neat_damage = cluttered_damage_stat[plus_position + 1:plus_position + 3]
                            print(neat_damage)

                await client.mouse_handler.set_mouse_position(0, 0)
            except AttributeError:
                continue


async def open_and_parse_backpack_contents(client):
    # Check if string contains icon (school) and damage (school)
    while not await get_window_from_path(client.root_window, ["WorldView", "DeckConfiguration", "InventorySpellbookPage"]):
        await client.send_key(Keycode.B, 0.1)
        await asyncio.sleep(.2)

    left_button = await get_window_from_path(client.root_window, ['WorldView', 'DeckConfiguration', 'InventorySpellbookPage', 'leftscroll'])
    right_button = await get_window_from_path(client.root_window, ['WorldView', 'DeckConfiguration', 'InventorySpellbookPage', 'rightscroll'])

    if await left_button.is_visible():
        while not await is_control_grayed(left_button):
            await client.mouse_handler.click_window(left_button)
        while not await is_control_grayed(right_button):
                await scan(client)
                await client.mouse_handler.click_window(right_button)
    # ABOVE WAS CAUSING INFINITY LOOP
    await scan(client)


async def main(walker):
    client = walker.get_new_clients()[0]
    await client.activate_hooks()
    await client.mouse_handler.activate_mouseless()
    print('starting')
    await open_and_parse_backpack_contents(client)


async def run():
    walker = WizWalker()
    try:
        await main(walker)
    except:
        import traceback
        traceback.print_exc()
    await walker.close()


if __name__ == "__main__":
    asyncio.run(run())
